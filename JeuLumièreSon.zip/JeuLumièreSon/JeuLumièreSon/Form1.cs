using static System.Windows.Forms.DataFormats;

namespace JeuLumièreSon
{
    public partial class Lumières : Form
    {
        //Variable Globale
        Random random = new Random();
        List<int> lst = new List<int>();
        int actif =0;
        int actuelChiffreList = 0;
        int block = 0;
        int speed = 500;
        int max = 0;
        public Lumières()
        {
            InitializeComponent();
        }
        //Changement de couleur initiale des bouttons
        private void Form1_Load(object sender, EventArgs e)
        {
            AffichageClean();
        }
        // Démarrer le jeu
        private void buttonOk_Click(object sender, EventArgs e)
        {
            if(block == 0) 
            {
                if (radioButtonEasy.Checked)
                {
                    speed = 500;
                    max = 5;
                }
                else if (radioButtonNormal.Checked)
                {
                    speed = 300;
                    max = 7;
                }
                else if (radioButtonHard.Checked)
                {
                    speed = 80;
                    max = 8;
                }
                else if (radioButtonExtreme.Checked)
                {
                    speed = 30;
                    max = 10;
                }
                else  
                {
                    speed = 500;
                    max = 5;
                }
                block = 1;
                buttonOk.Text = "Restart";
                SéquenceAdd();
            }
            else
            {
                string message = "Etes vous sur de recommencer?";
                string title = "Restart";
                var result = MessageBox.Show(message, title, MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    Restart();
                }
            }
           
            
        }
        //Fonction de réinitialisation du jeu
        public void Restart()
        {
            actuelChiffreList = 0;
            actif = 0;
            block = 0;
            lst.Clear();
            buttonOk.Text = "start";
        }
        //Quitter l'application
        private void buttonQuitter_Click(object sender, EventArgs e)
        {
            string message = "Etes vous sur de quitter le jeu?";
            string title = "Exit";
            var result = MessageBox.Show(message, title, MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        //Ajoue d'élélment
        public void SéquenceAdd()
        {
            if (actif == 0) 
            {
                lst.Add(random.Next(1,10));
               
                foreach (int item in lst)
                {
                    Affichage(item);
                    wait(speed);
                    AffichageClean();
                    wait(200);
                }
                actif = 1;
            }
        }
        //Boutton cliquer
        public int VérifClick(int n1)
        {
            if (actif == 1)
            {
                //Bon boutton cliquer
                if(n1 == lst[actuelChiffreList])
                {
                    actuelChiffreList++;
                    Affichage(n1);
                    wait(300);
                    AffichageClean();
                    if (actuelChiffreList == lst.Count) 
                    {
                        //Victoire
                        if(actuelChiffreList ==max) 
                        {
                            string message = "Voulez vous recommencer?";
                            string title = "Vous avez gagné";
                            var result = MessageBox.Show(message, title, MessageBoxButtons.YesNo);
                            if (result == DialogResult.Yes)
                            {
                                Restart();
                            }
                            else
                            {
                                Application.Exit();
                            }
                        }
                        //Ajoue d'élément à la séquence
                        else 
                        { 
                            wait(1000);
                            actuelChiffreList = 0;
                            actif =0;
                            SéquenceAdd();
                        }
                       
                    }
                }
                //Mauvais boutton cliquer
                else 
                {
                    AffichageFail(n1);
                    wait(500);
                    AffichageClean();
                    string message = "Voulez vous recommencer?";
                    string title = "Défaite";
                    var result = MessageBox.Show(message, title, MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        Restart();
                    }
                    else
                    {
                        Application.Exit();
                    }
                }
            }
                return 0;
        }
        // Changement de couleur des bouttons
        public void Affichage(int n1s)
        {
            switch (n1s)
            {
                case 1:
                    button1.BackColor = Color.DarkViolet;
                    break;
                case 2:
                    button2.BackColor = Color.DarkViolet;
                    break;
                case 3:
                    button3.BackColor = Color.DarkViolet;
                    break;
                case 4:
                    button4.BackColor = Color.DarkViolet;
                    break;
                case 5:
                    button5.BackColor = Color.DarkViolet;
                    break;
                case 6:
                    button6.BackColor = Color.DarkViolet;
                    break;
                case 7:
                    button7.BackColor = Color.DarkViolet;
                    break;
                case 8:
                    button8.BackColor = Color.DarkViolet;
                    break;
                case 9:
                    button9.BackColor = Color.DarkViolet;
                    break;
            }
        }
        //Changement de couleur si mauvais bouttons cliquer
        public void AffichageFail(int n1s)
        {
            switch (n1s)
            {
                case 1:
                    button1.BackColor = Color.Red;
                    break;
                case 2:
                    button2.BackColor = Color.Red;
                    break;
                case 3:
                    button3.BackColor = Color.Red;
                    break;
                case 4:
                    button4.BackColor = Color.Red;
                    break;
                case 5:
                    button5.BackColor = Color.Red;
                    break;
                case 6:
                    button6.BackColor = Color.Red;
                    break;
                case 7:
                    button7.BackColor = Color.Red;
                    break;
                case 8:
                    button8.BackColor = Color.Red;
                    break;
                case 9:
                    button9.BackColor = Color.Red;
                    break;
            }
        }
        //Mettre tous les bouttons à leur couleurs initiale
        public void AffichageClean()
        {
            button1.BackColor = Color.Gray;
            button2.BackColor = Color.Gray;
            button3.BackColor = Color.Gray;
            button4.BackColor = Color.Gray;
            button5.BackColor = Color.Gray;
            button6.BackColor = Color.Gray;
            button7.BackColor = Color.Gray; 
            button8.BackColor = Color.Gray;
            button9.BackColor = Color.Gray;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            VérifClick(1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VérifClick(2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            VérifClick(3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            VérifClick(4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            VérifClick(5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            VérifClick(6);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            VérifClick(7);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            VérifClick(8);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            VérifClick(9);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {      
        }
        //Fonction pour le timer
        public void wait(int milliseconds)
        {
            var timer1 = new System.Windows.Forms.Timer();
            if (milliseconds == 0 || milliseconds < 0) return;

            // Console.WriteLine("start wait timer");
            timer1.Interval = milliseconds;
            timer1.Enabled = true;
            timer1.Start();

            timer1.Tick += (s, e) =>
            {
                timer1.Enabled = false;
                timer1.Stop();
                // Console.WriteLine("stop wait timer");
            };

            while (timer1.Enabled)
            {
                Application.DoEvents();
            }
        }
    }
}